<?php
 include "dbconnection.php";
 if(isset($_POST['register']))
 {
 $firstname=$_POST['firstname'];
 $lastname=$_POST['lastname'];
$address=$_POST['address'];
$email=$_POST['email'];
$salary=$_POST['salary'];
$workinghour=$_POST['workinghour'];
 $query=mysql_query("INSERT INTO `employee` (`firstname`,`lastname`,`address`,`email`,`salary`,`workinghour`) VALUES ('$firstname','$lastname','$address','$email','$salary','$workinghour')");
 if($query)
  echo "ok";
 else
  echo "error";
 }
 ?>
