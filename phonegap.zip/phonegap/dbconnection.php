<?php
 header("Access-Control-Allow-Origin: *");
 mysql_connect("localhost","root","Lamichhina.123");
 mysql_select_db("phonegap_chatapp");

?>
