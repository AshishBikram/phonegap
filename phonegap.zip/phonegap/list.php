<?php
include("dbconnection.php");
include("Common.php");
//$objCommon = new Common();
//if(isset($_REQUEST['action']) && !empty($_REQUEST['action']))
//{
    $rs = mysql_query("Select distinct * from employee",$this->conn);
        $data = array();
        $i = 0;
        while($result = mysql_fetch_assoc($rs))
        {
            $data[$i]['e_id'] = $result["e_id"];
            $data[$i]['firstname'] = $result["firstname"];
            $data[$i]['lastname'] = $result["lastname"];
            $data[$i]['address'] = $result["address"];
            $data[$i]['email'] = $result["email"];
	    $data[$i]['salary'] = $result["salary"];
	    $data[$i]['workinghours'] = $result["workinghours"];
            $i++;
        }

   

    echo  json_encode($data);
//}
?>
