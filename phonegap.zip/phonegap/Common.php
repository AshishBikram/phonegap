<?php
/**
 * Created by IntelliJ IDEA.
 * User: sneupane
 * Date: 4/16/16
 * Time: 10:59 AM
 */

class Common {
    public $conn;

    function __construct()
    {
        global $conn;
        $this->conn = $conn;
    }

    public function getEmployee($inputdata='')
    {
        $rs = mysql_query("Select distinct * from employee",$this->conn);
        $data = array();
        $i = 0;
        while($result = mysql_fetch_assoc($rs))
        {
            $data[$i]['e_id'] = $result["e_id"];
            $data[$i]['firstname'] = $result["firstname"];
            $data[$i]['lastname'] = $result["lastname"];
            $data[$i]['address'] = $result["address"];
            $data[$i]['email'] = $result["email"];
	    $data[$i]['salary'] = $result["salary"];
	    $data[$i]['workinghours'] = $result["workinghours"];
            $i++;
        }
        return $data;

    }

}
?>
