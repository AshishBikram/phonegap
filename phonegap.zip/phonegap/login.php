<?php
include "dbconnection.php";
//if(isset($_POST['login']))
 //{
 $username=$_POST['username'];
 $password=$_POST['password'];
$q=mysql_query("select * from `user` WHERE username=$username && password=$password");
if($q) {
    echo "ok";
    }else{
    echo "error";
//}

 }
?>
