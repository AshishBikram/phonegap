<?php
 include "dbconnection.php";
 if(isset($_GET['register']))
 {
 $username=$_GET['username'];
 $password=$_GET['password'];

 $q=mysql_query("INSERT INTO `user` (`username`,`password`) VALUES ('$username','$password')");
 if($q)
  echo "ok";
 else
  echo "error";
 }
 ?>
